package uta.edu.estudiante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Expo4Application {

	public static void main(String[] args) {
		SpringApplication.run(Expo4Application.class, args);
	}

}
